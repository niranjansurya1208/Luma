<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>list_Items</name>
   <tag></tag>
   <elementGuidId>239402e5-d8fb-4f37-9706-dc059d85684b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>${xpath}</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//ol[@class='products list items product-items']/li[2]/div/a[text()]</value>
      <webElementGuid>1834dbfd-0578-445a-9533-f8babaf26918</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
