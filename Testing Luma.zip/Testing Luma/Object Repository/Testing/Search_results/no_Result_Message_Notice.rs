<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>no_Result_Message_Notice</name>
   <tag></tag>
   <elementGuidId>90cd1075-1ce2-4476-a0d9-998c55d8a049</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class='message notice']//div[contains(.,'Your search returned no results.')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>(//div[@class='message notice']//text())[2]</value>
      <webElementGuid>86e8d96e-eb94-45af-8044-48fc098ccd8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <type>Main</type>
      <value>//div[@class='message notice']//div[contains(.,'Your search returned no results.')]</value>
      <webElementGuid>1c154afa-22dd-4fb2-aabd-c7fa442d3fcc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
