
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "testing.common.openApplication"(
    	String Url	) {
    (new testing.common()).openApplication(
        	Url)
}


def static "testing.common.logIn"(
    	String email	
     , 	String password	) {
    (new testing.common()).logIn(
        	email
         , 	password)
}


def static "testing.common.logOut"() {
    (new testing.common()).logOut()
}


def static "browser.excelhandler.getdatabymap"(
    	String filePath	
     , 	String SheetName	) {
    (new browser.excelhandler()).getdatabymap(
        	filePath
         , 	SheetName)
}
