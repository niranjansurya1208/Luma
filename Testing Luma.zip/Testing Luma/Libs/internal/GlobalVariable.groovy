package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object url
     
    /**
     * <p></p>
     */
    public static Object email
     
    /**
     * <p></p>
     */
    public static Object Password
     
    /**
     * <p></p>
     */
    public static Object currentTestCaseId
     
    /**
     * <p></p>
     */
    public static Object reportsFolder
     
    /**
     * <p></p>
     */
    public static Object ssNo
     
    /**
     * <p></p>
     */
    public static Object TestSuiteId
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += TestCaseMain.getParsedValues(RunConfiguration.getOverridingParameters(), selectedVariables)
    
            url = selectedVariables['url']
            email = selectedVariables['email']
            Password = selectedVariables['Password']
            currentTestCaseId = selectedVariables['currentTestCaseId']
            reportsFolder = selectedVariables['reportsFolder']
            ssNo = selectedVariables['ssNo']
            TestSuiteId = selectedVariables['TestSuiteId']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
