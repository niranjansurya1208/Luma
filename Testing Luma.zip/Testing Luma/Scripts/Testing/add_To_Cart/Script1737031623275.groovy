import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable
import static org.junit.Assert.assertEquals
import org.openqa.selenium.Keys as Keys
import browser.excelhandler
import browser.screenshot
import testing.common

'Open the browser and application url'
common.openApplication(GlobalVariable.url)

'User login to the application'
common.logIn(GlobalVariable.email,GlobalVariable.Password)

'Take the Screenshot of homepage after Signin'
screenshot.takescreenshot()

'Select the required menu'
WebUI.click(findTestObject('Object Repository/Testing/Homepage/menuTab',['menuName':'Men']))

'Go to the required category'
WebUI.scrollToElement(findTestObject('Object Repository/Testing/Homepage/category',['categoryName':'Jackets']), 30)
WebUI.click(findTestObject('Object Repository/Testing/Homepage/category',['categoryName':'Jackets']))

'Select the second item'
'We Want to select the second item so the li index is 2'
WebUI.scrollToElement(findTestObject('Object Repository/Testing/Common_elements/list_Items',['xpath':"//ol[@class='products list items product-items']/li[2]/div/a[text()]"]), 30)
WebUI.click(findTestObject('Object Repository/Testing/Common_elements/list_Items',['xpath':"//ol[@class='products list items product-items']/li[2]/div/a[text()]"]))

'Select the size of the Item'
WebUI.waitForElementClickable(findTestObject('Object Repository/Testing/Common_elements/size_Of_Item',['size':'XS']), 30)
WebUI.click(findTestObject('Object Repository/Testing/Common_elements/size_Of_Item',['size':'XS']))

'Select the color of the Item'
WebUI.waitForElementClickable(findTestObject('Object Repository/Testing/Common_elements/color_Of_Item',['color':'Black']), 30)
WebUI.click(findTestObject('Object Repository/Testing/Common_elements/color_Of_Item',['color':'Black']))

'Add the item to add to cart'
WebUI.waitForElementClickable(findTestObject('Object Repository/Testing/Common_elements/add_To_Cart_Btn'), 30)
WebUI.verifyElementClickable(findTestObject('Object Repository/Testing/Common_elements/add_To_Cart_Btn'), FailureHandling.STOP_ON_FAILURE)
WebUI.click(findTestObject('Object Repository/Testing/Common_elements/add_To_Cart_Btn'))

'Take the Screenshot the item page after adding the item to cart'
screenshot.takescreenshot()

'Logout the Account'
common.logOut()

'Take the Screenshot of signout page'
screenshot.takescreenshot()

'Close the browser'
WebUI.closeBrowser()







