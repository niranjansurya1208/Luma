import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable
import static org.junit.Assert.assertEquals
import org.openqa.selenium.Keys as Keys
import browser.excelhandler
import browser.screenshot
import testing.common

'Open the browser and application url'
common.openApplication(GlobalVariable.url)

'User login to the application'
common.logIn(GlobalVariable.email,GlobalVariable.Password)

'Take the Screenshot of homepage after Signin'
screenshot.takescreenshot()

'Go to the my cart page'
WebUI.scrollToElement(findTestObject('Object Repository/Testing/Headerpanel/welcome_Message'), 10)
WebUI.click(findTestObject('Object Repository/Testing/Headerpanel/myCart_Btn'))
WebUI.waitForElementClickable(findTestObject('Object Repository/Testing/Mycart/view_Edit_Btn'), 30)
WebUI.click(findTestObject('Object Repository/Testing/Mycart/view_Edit_Btn'))

'Click the proceed to checkout Button'
WebUI.verifyElementClickable(findTestObject('Object Repository/Testing/Mycart/proceed_To_Checkout_Btn'), FailureHandling.STOP_ON_FAILURE)
WebUI.click(findTestObject('Object Repository/Testing/Mycart/proceed_To_Checkout_Btn'))

'Fill the shipping details'
WebUI.waitForElementVisible(findTestObject('Object Repository/Testing/Mycart/Shipping/street_Input',['xpath':"//input[@name='street[0]']"]), 30)
def data = TestDataFactory.findTestData("shipping_Details")
WebUI.setText(findTestObject('Object Repository/Testing/Mycart/Shipping/street_Input',['xpath':"//input[@name='street[0]']"]), data.getValue(1, 1))
WebUI.setText(findTestObject('Object Repository/Testing/Mycart/Shipping/street_Input',['xpath':"//input[@name='street[1]']"]), data.getValue(2, 1))
WebUI.setText(findTestObject('Object Repository/Testing/Mycart/Shipping/street_Input',['xpath':"//input[@name='street[2]']"]), data.getValue(3, 1))
WebUI.setText(findTestObject('Object Repository/Testing/Mycart/Shipping/city_Input'),data.getValue(4, 1))
WebUI.selectOptionByLabel(findTestObject('Object Repository/Testing/Mycart/Shipping/state_DD'),data.getValue(5, 1), false)
WebUI.setText(findTestObject('Object Repository/Testing/Mycart/Shipping/postalcode_Input'), data.getValue(6, 1))
WebUI.selectOptionByLabel(findTestObject('Object Repository/Testing/Mycart/Shipping/country_DD'), data.getValue(7, 1), false)
WebUI.setText(findTestObject('Object Repository/Testing/Mycart/Shipping/phone_Number'),data.getValue(8, 1))
def method=data.getValue(9, 1)
WebUI.click(findTestObject('Object Repository/Testing/Mycart/Shipping/shipping_Method',['shippingmethod':method]))
WebUI.click(findTestObject('Object Repository/Testing/Mycart/Shipping/next_Btn'))

'Take the Screenshot of the page after filling the shipping details'
screenshot.takescreenshot()

'Fill the Payment and Review details'
'Click the my billing address checkbox'
WebUI.click(findTestObject('Object Repository/Testing/Mycart/Review_Payments/billingAddress_Checkbox'))

'Take the Screenshot of the page after filling the review and payment details'
screenshot.takescreenshot()

'Click the place order button'
WebUI.waitForPageLoad(30)
WebUI.verifyElementClickable(findTestObject('Object Repository/Testing/Mycart/Review_Payments/placeOrder_Btn'), FailureHandling.STOP_ON_FAILURE)
WebUI.click(findTestObject('Object Repository/Testing/Mycart/Review_Payments/placeOrder_Btn'))

'Take the Screenshot of the page after place the order'
screenshot.takescreenshot()

'Logout the Account'
common.logOut()

'Take the Screenshot of signout page'
screenshot.takescreenshot()

'Close the browser'
WebUI.closeBrowser()








