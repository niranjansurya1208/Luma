import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable
import static org.junit.Assert.assertEquals
import org.openqa.selenium.Keys as Keys
import browser.excelhandler
import browser.screenshot
import testing.common

'Open the browser and application url'
common.openApplication(GlobalVariable.url)

'Verify the create an account link is clickable'
WebUI.verifyElementClickable(findTestObject('Object Repository/Testing/Headerpanel/create_An_Account_Link_Btn'), FailureHandling.STOP_ON_FAILURE)
'Click the create an account link'
WebUI.click(findTestObject('Object Repository/Testing/Headerpanel/create_An_Account_Link_Btn'))

'Take the path of the required excel'
def excelPath=RunConfiguration.getProjectDir()+'/Resources/Testing.xlsx'

'Map the xpath and value by using excel'
def create_Account= excelhandler.getdatabymap(excelPath, "Create_Account")
System.out.println(create_Account)
create_Account.each {key , value->
	
	'Current input field'
	System.out.println('The input field is'+ key)
    'Scroll to the required input field'
    WebUI.scrollToElement(findTestObject('Object Repository/Testing/Create_an_account_page/create_Account_Page_Txtbx',['TxtbxName':key]), 10)
	'Verify that input field is visible or not'
	WebUI.verifyElementVisible(findTestObject('Object Repository/Testing/Create_an_account_page/create_Account_Page_Txtbx',['TxtbxName':key]), FailureHandling.STOP_ON_FAILURE)	
	'Enter the value in that input field'
	WebUI.setText(findTestObject('Object Repository/Testing/Create_an_account_page/create_Account_Page_Txtbx',['TxtbxName':key]), value)
	
}

'Take the screenshot of the create an account page with data'
screenshot.takescreenshot()

'Verify the create an account button is clickable'
WebUI.verifyElementClickable(findTestObject('Object Repository/Testing/Create_an_account_page/create_An_Account_Btn'), FailureHandling.STOP_ON_FAILURE)
'Click the create an account button'
WebUI.click(findTestObject('Object Repository/Testing/Create_an_account_page/create_An_Account_Btn'))

'Take the screenshot of my account page'
screenshot.takescreenshot()

'Wait for message to show'
WebUI.waitForElementVisible(findTestObject('Object Repository/Testing/MyAccount_page/page_Mesaage'), 30)
'Get the text from the message'
actual_Mesaage=WebUI.getText(findTestObject('Object Repository/Testing/MyAccount_page/page_Mesaage'))
System.out.println(actual_Mesaage)

'Verify the registration is successful by using page message '
assertEquals(expected_Message, actual_Mesaage)

'Take the Screenshot of registration sucessful page'
screenshot.takescreenshot()

'Logout the Account'
common.logOut()

'Take the Screenshot of signout page'
screenshot.takescreenshot()

'Close the browser'
WebUI.closeBrowser()



