package testing

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.util.KeywordUtil
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows

public class common {

	@Keyword
	def public static openApplication(String Url) {

		WebUI.openBrowser(Url)
		WebUI.maximizeWindow()
		WebUI.waitForPageLoad(30)
	}

	@Keyword
	def public static logIn(String email,String password) {
		'Verify the signIn link is clickable'
		WebUI.verifyElementClickable(findTestObject('Object Repository/Testing/Headerpanel/sign_In_Link_Btn'), FailureHandling.STOP_ON_FAILURE)
		'Click the signIn link'
		WebUI.click(findTestObject('Object Repository/Testing/Headerpanel/sign_In_Link_Btn'))
		'verify the email input field is visible'
		WebUI.verifyElementVisible(findTestObject('Object Repository/Testing/SignIn_page/email_Input'), FailureHandling.STOP_ON_FAILURE)
		'Enter the value in that input field'
		WebUI.setText(findTestObject('Object Repository/Testing/SignIn_page/email_Input'),email)
		'verify the password input field is visible'
		WebUI.verifyElementVisible(findTestObject('Object Repository/Testing/SignIn_page/password_Input'), FailureHandling.STOP_ON_FAILURE)
		'Enter the value in that input field'
		WebUI.setEncryptedText(findTestObject('Object Repository/Testing/SignIn_page/password_Input'),password)
		'Verify the signIn button is clickable'
		WebUI.verifyElementClickable(findTestObject('Object Repository/Testing/SignIn_page/signIn_Btn'), FailureHandling.STOP_ON_FAILURE)
		'Click the signIn button'
		WebUI.click(findTestObject('Object Repository/Testing/SignIn_page/signIn_Btn'))
		'Verify the user is successfully signIn'
		WebUI.verifyElementVisible(findTestObject('Object Repository/Testing/Headerpanel/welcome_Message'), FailureHandling.STOP_ON_FAILURE)
		'Printn that signin message'
		def user=WebUI.getText(findTestObject('Object Repository/Testing/Headerpanel/welcome_Message'))
		KeywordUtil.logInfo(user)
		WebUI.waitForPageLoad(30)
	}


	@Keyword
	def public static logOut() {
		'verify the element is present and click the profile dropdown button'
		WebUI.verifyElementPresent(findTestObject('Object Repository/Testing/Headerpanel/profile_Dropdown_Button'), 30, FailureHandling.STOP_ON_FAILURE)
		WebUI.click(findTestObject('Object Repository/Testing/Headerpanel/profile_Dropdown_Button'))

		'Wait for the element to visible and click the signout button'
		WebUI.waitForElementVisible(findTestObject('Object Repository/Testing/Headerpanel/profile_DD_Signout'), 30, FailureHandling.STOP_ON_FAILURE)
		WebUI.click(findTestObject('Object Repository/Testing/Headerpanel/profile_DD_Signout'))
	}
}
